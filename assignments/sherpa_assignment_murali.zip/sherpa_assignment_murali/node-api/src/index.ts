// File: src/index.ts
import express, { Request, Response } from 'express';
import sqlite3 from 'sqlite3';
import { open, Database } from 'sqlite';
import path from 'path';


const app = express();
app.use(express.json());
const PORT = process.env.PORT || 3000;

async function openDb(): Promise<Database> {
    const dbPath = path.join(__dirname, '../../', 'usersinfo.db');
    return open({
      filename: dbPath,
      driver: sqlite3.Database,
    });
  }
  
app.get('/api/users/postalcode/:postalCode', async (req: Request, res: Response) => {
  const postalCode = req.params.postalCode;

  try {
    const db = await openDb();
    const users = await db.all(
      'SELECT users.username FROM users JOIN postal_codes ON users.id = postal_codes.user_id WHERE postal_codes.postal_code = ?',
      postalCode
    );
    res.json({ status: 'success', users });
  } catch (error) {
    console.error('Error fetching users by postal code:', error);
    res.status(500).json({ status: 'error', message: 'An error occurred while fetching users' });
  }
});

app.delete("/api/users/postalcode/:postal_code", async (req: Request, res: Response) => {
    const postalCode = req.params.postal_code;
    try {
      const db = await openDb();
      const userIds = await db.all("SELECT user_id FROM postal_codes WHERE postal_code = ?", postalCode);
      
      // Start a transaction
      await db.run("BEGIN");
  
      // Remove user associations with the given postal code
      await db.run("DELETE FROM postal_codes WHERE postal_code = ?", postalCode);
      
      // Loop through the user ids and remove the user from all other postal codes and the users table
      for (const userId of userIds) {
        await db.run("DELETE FROM postal_codes WHERE user_id = ?", userId.user_id);
        await db.run("DELETE FROM users WHERE id = ?", userId.user_id);
      }
      
      // Commit the transaction
      await db.run("COMMIT");
  
      res.status(200).json({ status: "success", message: "Users removed successfully" });
    } catch (error) {
      console.error("Error removing users by postal code:", error);
      res.status(500).json({ status: "error", message: "An error occurred while removing users" });
    }
  });
  
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
