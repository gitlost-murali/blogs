
# Flask Application

## Decisions:

1. If the user is not in the database, then the user and postcode are added to the database.
Decisions made:
2. If the user is already in the database, but the postcode is different, then the postcode table is updated.
3. If the user and postcode are already, then the entry is not added again and we send a INFO (512 code - custom) response. Not an error message.
4. We send an error message only when the request is not valid (e.g. no username or no postcode).


## App details

`app.py` is the main file.

1. The app is a Flask application using a sqlite3 database (`usersinfo.db`) working as an API.
2. The database a single table for users and a single table for postcodes.
3. We use a single endpoint for adding users.
4. If there's no database, we create one

## Installation

```
pip install -r requirements.txt
```

## Running

```
python app.py # To run the flask application
python test_app.py # To run the tests
curl -X POST -H "Content-Type: application/json" -d '{"username": "kiran", "postal_code": "9711SJ"}' http://localhost:5000/api/users
```

# Node.js part

## Installing npm

```
cd node-api/
npm install typescript && npm install express && npm install sqlite3 
npm install @types/node && npm install @types/express
npm run build
```

node.js files are available under node-api/ folder:
* node-api/src/index.ts - main file where the endpoints are defined

Try them:

```
npm start
curl -X GET "http://localhost:3000/api/users/postalcode/9711SJ"
curl -X DELETE "http://localhost:3000/api/users/postalcode/9711SJ"
```
