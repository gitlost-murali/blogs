# File: test_app.py
import unittest
import json
from app import app, get_db, init_db

USERNAME = 'kiran'
class TestApp(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        with app.app_context():
            init_db()

    def test_add_user(self):
        with app.app_context():
            db = get_db()

            data = {'username': USERNAME, 'postal_code': '10001'}
            response = self.app.post('/api/users', data=json.dumps(data), content_type='application/json')

            self.assertTrue(response.status_code ==201 or response.status_code == 512)
            self.assertTrue(response.json['status'] == 'success' or response.json['status'] == 'info')
            self.assertTrue(response.json['message'] == 'User and postal code information added successfully'
                            or response.json['message'] == 'Postal code already exists for this user')

            user = db.execute('SELECT * FROM users WHERE username=?', (USERNAME,)).fetchone()
            self.assertIsNotNone(user)

            postal_code_entry = db.execute('SELECT * FROM postal_codes WHERE user_id=?', (user[0],)).fetchone()
            self.assertIsNotNone(postal_code_entry)
            self.assertEqual(postal_code_entry[1], '10001')
            self.assertEqual(postal_code_entry[2], 'Bouira Cite El Badr')

    def test_add_multiple_postal_codes(self):
        with app.app_context():
            db = get_db()

            data = {'username': USERNAME, 'postal_code': '10001'}
            response = self.app.post('/api/users', data=json.dumps(data), content_type='application/json')
            self.assertTrue(response.status_code ==201 or response.status_code == 512)
            self.assertTrue(response.json['status'] == 'success' or response.json['status'] == 'info')
            self.assertTrue(response.json['message'] == 'User and postal code information added successfully'
                            or response.json['message'] == 'Postal code already exists for this user')


            data = {'username': USERNAME, 'postal_code': '90210'}
            response = self.app.post('/api/users', data=json.dumps(data), content_type='application/json')
            self.assertTrue(response.status_code ==201 or response.status_code == 512)
            self.assertTrue(response.json['status'] == 'success' or response.json['status'] == 'info')
            self.assertTrue(response.json['message'] == 'User and postal code information added successfully'
                            or response.json['message'] == 'Postal code already exists for this user')


            user = db.execute('SELECT * FROM users WHERE username=?', (USERNAME,)).fetchone()
            self.assertIsNotNone(user)

            postal_codes = db.execute('SELECT * FROM postal_codes WHERE user_id=?', (user[0],)).fetchall()
            self.assertGreater(len(postal_codes), 0)

            postal_code_data = {pc[1]: pc[2] for pc in postal_codes}
            self.assertEqual(postal_code_data['10001'], 'Bouira Cite El Badr')
            self.assertEqual(postal_code_data['90210'], 'Amantla')

    def test_add_duplicate_postal_code(self):
        with app.app_context():
            db = get_db()

            data = {'username': USERNAME, 'postal_code': '10001'}
            response = self.app.post('/api/users', data=json.dumps(data), content_type='application/json')
            self.assertTrue(response.status_code == 201 or response.status_code == 512)
            self.assertTrue(response.json['status'] == 'success' or response.json['status'] == 'info')
            self.assertTrue(response.json['message'] == 'User and postal code information added successfully'
                            or response.json['message'] == 'Postal code already exists for this user')


            data = {'username': USERNAME, 'postal_code': '10001'}
            response = self.app.post('/api/users', data=json.dumps(data), content_type='application/json')
            self.assertEqual(response.status_code, 512)
            self.assertEqual(response.json['status'], 'info')
            self.assertEqual(response.json['message'], 'Postal code already exists for this user')

if __name__ == '__main__':
    unittest.main()
