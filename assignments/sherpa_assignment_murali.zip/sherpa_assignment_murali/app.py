import os
import sqlite3
from flask import Flask, request, jsonify, g
import requests

app = Flask(__name__)
DATABASE = 'usersinfo.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

@app.teardown_appcontext # called when the application context is shutdown
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    # If database exists, return None
    # Else, create database and tables
    if os.path.exists(DATABASE):
        return
    with app.app_context():
        db = get_db()
        db.cursor().executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS postal_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                postal_code TEXT NOT NULL,
                city TEXT NOT NULL,
                user_id INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
        """)
        db.commit()


@app.route('/api/users', methods=['POST'])
def add_user():
    username = request.json['username']
    postal_code = request.json['postal_code']

    geo_url = f'http://api.geonames.org/postalCodeLookupJSON?postalcode={postal_code}&username={username}'
    response = requests.get(geo_url).json()

    if 'postalcodes' not in response or len(response['postalcodes']) == 0:
        return jsonify({'status': 'error', 'message': f'Response returned is {response}'}), 400

    city = response['postalcodes'][0]['placeName']

    db = get_db()

    user = db.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()

    if user is None:
        db.execute('INSERT INTO users (username) VALUES (?)', (username,))
        db.commit()
        user_id = db.execute('SELECT id FROM users WHERE username=?', (username,)).fetchone()[0]
    else:
        user_id = user[0]

    existing_postal_code = db.execute('SELECT * FROM postal_codes WHERE postal_code=? AND user_id=?', (postal_code, user_id)).fetchone()
    print(f"Existing postal code: {existing_postal_code}, {postal_code},user_id: {user_id}")

    if existing_postal_code is None:
        db.execute('INSERT INTO postal_codes (postal_code, city, user_id) VALUES (?, ?, ?)', (postal_code, city, user_id))
        db.commit()
        return jsonify({'status': 'success', 'message': 'User and postal code information added successfully'}), 201
    else:
        print("postal code already exists for this user!")
        return jsonify({'status': 'info', 'message': 'Postal code already exists for this user'}), 512

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
